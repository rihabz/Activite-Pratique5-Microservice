package com.eyasin.comptecqrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompteCqrsApplicationTests {

    @Test
    void contextLoads() {
    }

}
