package com.eyasin.comptecqrs.enums;

public enum OperationType {
    DEBIT,CREDIT
}
