package com.eyasin.comptecqrs.enums;

public enum AccountStatus {
    CREATED,ACTIVATED
}
