package com.eyasin.comptecqrs.queries.dto;

public class GetAllAccountsRequestDTO {
}
