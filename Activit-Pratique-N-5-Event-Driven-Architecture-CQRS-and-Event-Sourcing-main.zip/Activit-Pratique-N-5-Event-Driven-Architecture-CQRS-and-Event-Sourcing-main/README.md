
## strcture de project
![alt text](images/img_1.png)
## package command
![alt text](images/img.png)
## package events
![alt text](images/img_2.png)
## package queries
![alt text](images/img_3.png)

## Test
### create account
![alt text](images/img_4.png)
### credit account
![alt text](images/img_5.png)
### generated events
![alt text](images/img_6.png)
### debit account
![alt text](images/img_7.png)
### generated events
![alt text](images/img_8.png)


